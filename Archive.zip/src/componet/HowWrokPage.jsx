import React from "react"

const HowWrokPage = () => {
  return (
    <div className="">
      <section className="lg:pt-24 lg:px-0 px-6  py-10">
        <div className="mb-12 md:text-center">
          <h1 className="text-2xl font-bold">How it works</h1>
        </div>
        <div className="max-w-5xl mx-auto text-left md:text-center">
          <p>
            Selling your unwanted new LEGO® set to lego2sell.com is easy!
            There's no need to worry about messing around trying to sell on
            platforms and waiting weeks to get paid or dealing with customers
            and their returns you just sell to us. We accept nearly all new
            sets, Just type in the code see your set appear and get an instant
            offer.
          </p>
        </div>
      </section>
      <section className="py-8 lg:px-0 px-6 lg:pt-10 lg:pb-20 relative overflow-hidden">
        <div className="absolute top-[50%] left-0 right-0 bg-[#F8F8FE] bottom-0 z-0" />
        <div className="">
          {/* <div className="aspect-video mx-auto max-w-5xl rounded-lg flex items-center justify-center text-5xl my-12 z-10 relative">
            <video
              loop=""
              playsInline=""
              preload="auto"
              controls=""
              poster="/img/video_poster.jpg"
              className="rounded-lg overflow-hidden"
            >
              <source src="https://player.vimeo.com/progressive_redirect/playback/839685270/rendition/1080p/file.mp4?loc=external&log_user=0&signature=8ece92c98b8a30e61862fe0cec6196a9f05b43dd04bd0e2818168f2038de1ac9" />
            </video>
            <div className="hidden md:block absolute left-[-280px] bottom-0">
              <span
                style={{
                  boxSizing: "border-box",
                  display: "inline-block",
                  overflow: "hidden",
                  width: "initial",
                  height: "initial",
                  background: "none",
                  opacity: 1,
                  border: 0,
                  margin: 0,
                  padding: 0,
                  position: "relative",
                  maxWidth: "100%",
                }}
              >
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "block",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    maxWidth: "100%",
                  }}
                >
                  <img
                    alt=""
                    aria-hidden="true"
                    src="data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27251%27%20height=%27242%27/%3e"
                    style={{
                      display: "block",
                      maxWidth: "100%",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                    }}
                  />
                </span>
                <img
                  alt="bricks left"
                  src="/_next/static/media/how_bricks_1.5cdffa0a.svg"
                  decoding="async"
                  data-nimg="intrinsic"
                  style={{
                    position: "absolute",
                    inset: 0,
                    boxSizing: "border-box",
                    padding: 0,
                    border: "none",
                    margin: "auto",
                    display: "block",
                    width: 0,
                    height: 0,
                    minWidth: "100%",
                    maxWidth: "100%",
                    minHeight: "100%",
                    maxHeight: "100%",
                  }}
                  srcSet="/_next/static/media/how_bricks_1.5cdffa0a.svg 1x, /_next/static/media/how_bricks_1.5cdffa0a.svg 2x"
                />
              </span>
            </div>
            <div className="hidden md:block absolute right-[-360px] top-0">
              <span
                style={{
                  boxSizing: "border-box",
                  display: "inline-block",
                  overflow: "hidden",
                  width: "initial",
                  height: "initial",
                  background: "none",
                  opacity: 1,
                  border: 0,
                  margin: 0,
                  padding: 0,
                  position: "relative",
                  maxWidth: "100%",
                }}
              >
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "block",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    maxWidth: "100%",
                  }}
                >
                  <img
                    alt=""
                    aria-hidden="true"
                    src="data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27405%27%20height=%27404%27/%3e"
                    style={{
                      display: "block",
                      maxWidth: "100%",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                    }}
                  />
                </span>
                <img
                  alt="bricks right"
                  src="/_next/static/media/how_bricks_2.fb368a90.svg"
                  decoding="async"
                  data-nimg="intrinsic"
                  style={{
                    position: "absolute",
                    inset: 0,
                    boxSizing: "border-box",
                    padding: 0,
                    border: "none",
                    margin: "auto",
                    display: "block",
                    width: 0,
                    height: 0,
                    minWidth: "100%",
                    maxWidth: "100%",
                    minHeight: "100%",
                    maxHeight: "100%",
                  }}
                  srcSet="/_next/static/media/how_bricks_2.fb368a90.svg 1x, /_next/static/media/how_bricks_2.fb368a90.svg 2x"
                />
              </span>
            </div>
          </div> */}
        </div>
      </section>
      <section className="py-10 lg:px-0 px-6 flex items-center justify-center lg:pb-20 lg:pt-20 bg-[#F8F8FE] overflow-hidden">
        <div className=" text-center max-w-7xl">
          <h2 className="h1 mb-16">
            Sell Your New LEGO® Sets In 4 Easy Steps….
          </h2>
          <div className="relative mb-16">
            <div className="absolute left-[40px] lg:left-[50%] top-0 bottom-0 w-[4px] bg-[#EAEAFC] ml-[-2px]" />
            <div
              className="react-reveal relative flex flex-col pl-[100px] lg:pl-0 lg:grid gap-10 lg:gap-32 grid-rows-2 lg:grid-cols-2 lg:grid-rows-none items-center pb-20"
              style={{
                animationFillMode: "both",
                animationDuration: "1000ms",
                animationDelay: "0ms",
                animationIterationCount: 1,
                opacity: 1,
                animationName: "react-reveal-401627926166202-1",
              }}
            >
              <div className="absolute left-[40px] lg:left-[50%] top-0 bottom-0 w-[4px] bg-[#706AEA] ml-[-2px]" />
              <div className="absolute left-[40px] lg:left-[50%] top-0 ml-[-25px] mt-[-30px] w-[50px] h-[50px]">
                <img
                  data-aos="fade-up"
                  alt="Step marker"
                  src="./Images/timeline_marker.e6d0b1ec.svg"
                  decoding="async"
                  data-nimg="intrinsic"
                  style={{
                    position: "absolute",
                    inset: 0,
                    boxSizing: "border-box",
                    padding: 0,
                    border: "none",
                    margin: "auto",
                    display: "block",
                    width: 0,
                    height: 0,
                    minWidth: "100%",
                    maxWidth: "100%",
                    minHeight: "100%",
                    maxHeight: "100%",
                  }}
                />
              </div>
              <div className="order-2 lg:order-1 text-left">
                <div className="text-xl lg:text-3xl font-bold mb-8">
                  <span className="text-[#706AEA]">1.</span>Search Your LEGO®
                  code
                </div>
                <p className="leading-7">
                  Simply pop your LEGO® and hit search where your set and set
                  number will pop up with the options to choose your condition
                </p>
              </div>
              <div className="order-1 lg:order-2">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      data-aos="fade-up"
                      className="rounded-3xl"
                      alt=""
                      aria-hidden="true"
                      src="./Images/SearchLego.png"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
            </div>
            <div className="react-reveal relative flex flex-col pl-[100px] lg:pl-0 lg:grid gap-10 lg:gap-32 grid-rows-2 lg:grid-cols-2 lg:grid-rows-none items-center pb-20">
              <div className="absolute left-[40px] lg:left-[50%] top-0 bottom-0 w-[4px] bg-[#706AEA] ml-[-2px]" />
              <div className="absolute left-[40px] lg:left-[50%] top-0 ml-[-25px] mt-[-30px] w-[50px] h-[50px]">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      data-aos="fade-up"
                      alt=""
                      aria-hidden="true"
                      src="./Images/timeline_marker.e6d0b1ec.svg"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
              <div className="order-2 lg:order-2 text-left">
                <div className="text-xl lg:text-3xl font-bold mb-8">
                  <span className="text-[#706AEA]">2.</span>Get an instant offer
                </div>
                <p className="leading-7">
                  Confirm your set and accept the quote, fill out the details
                  and get your shipping information
                </p>
              </div>
              <div className="order-1 lg:order-1">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      data-aos="fade-up"
                      className="rounded-3xl"
                      alt=""
                      aria-hidden="true"
                      src="./Images/instantofferimage.jpeg"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
            </div>
            <div className="react-reveal relative flex flex-col pl-[100px] lg:pl-0 lg:grid gap-10 lg:gap-32 grid-rows-2 lg:grid-cols-2 lg:grid-rows-none items-center pb-20">
              <div className="absolute left-[40px] lg:left-[50%] top-0 bottom-0 w-[4px] bg-[#706AEA] ml-[-2px]" />
              <div className="absolute left-[40px] lg:left-[50%] top-0 ml-[-25px] mt-[-30px] w-[50px] h-[50px]">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      data-aos="fade-up"
                      alt=""
                      aria-hidden="true"
                      src="./Images/timeline_marker.e6d0b1ec.svg"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
              <div data-aos="fade-up" className="order-2 lg:order-1 text-left">
                <div className="text-xl lg:text-3xl font-bold mb-8">
                  <span className="text-[#706AEA]">3.</span> Send it to us
                </div>
                <p className="leading-7">
                  package up your LEGO® set and pop it in the post.
                </p>
              </div>
              <div className="order-1 lg:order-2">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      data-aos="fade-up"
                      className="rounded-3xl"
                      alt=""
                      aria-hidden="true"
                      src="./Images/postittousimage.jpeg"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
            </div>
            <div className="react-reveal relative flex flex-col pl-[100px] lg:pl-0 lg:grid gap-10 lg:gap-32 grid-rows-2 lg:grid-cols-2 lg:grid-rows-none items-center pb-20">
              <div className="absolute left-[40px] lg:left-[50%] top-0 bottom-0 w-[4px] bg-[#706AEA] ml-[-2px]" />
              <div className="absolute left-[40px] lg:left-[50%] top-0 ml-[-25px] mt-[-30px] w-[50px] h-[50px]">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      alt=""
                      aria-hidden="true"
                      src="./Images/timeline_marker.e6d0b1ec.svg"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
              <div data-aos="fade-up" className="order-2 lg:order-2 text-left">
                <div className="text-xl lg:text-3xl font-bold mb-8">
                  <span className="text-[#706AEA]">4.</span> Get paid
                </div>
                <p className="leading-7">
                  Choose either bank transfer or PayPal and, once your LEGO® set
                  has been checked and accepted, see the money land in your bank
                  or PayPal the very next day!
                </p>
              </div>
              <div className="order-1 lg:order-1">
                <span
                  style={{
                    boxSizing: "border-box",
                    display: "inline-block",
                    overflow: "hidden",
                    width: "initial",
                    height: "initial",
                    background: "none",
                    opacity: 1,
                    border: 0,
                    margin: 0,
                    padding: 0,
                    position: "relative",
                    maxWidth: "100%",
                  }}
                >
                  <span
                    style={{
                      boxSizing: "border-box",
                      display: "block",
                      width: "initial",
                      height: "initial",
                      background: "none",
                      opacity: 1,
                      border: 0,
                      margin: 0,
                      padding: 0,
                      maxWidth: "100%",
                    }}
                  >
                    <img
                      data-aos="fade-up"
                      className="rounded-3xl"
                      alt=""
                      aria-hidden="true"
                      src="./Images/GetpaidImage.png"
                      style={{
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0,
                      }}
                    />
                  </span>
                </span>
              </div>
            </div>
          </div>
          <div data-aos="fade-up" className="mb-12 md:text-center">
            <h1 className="text-2xl font-bold">
              So don’t delay and sell today!
            </h1>
          </div>
          <a
            data-aos="fade-up"
            title="Start selling LEGO®"
            className="flex w-full lg:inline-flex lg:w-auto justify-center items-center px-6 lg:px-12 rounded-xl bg-blue-500 text-white font-bold text-[15px] h-[49px] lg:h-[65px] xl:text-[18px]"
            href="/lego2sell-client"
          >
            Get Selling That LEGO®
          </a>
        </div>
      </section>
    </div>
  )
}

export default HowWrokPage
